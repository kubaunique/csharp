# How it looks
![The way it looks](https://i.imgur.com/O7AVQKA.gif)
